package com.adskipper.app;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.content.Context;
import android.graphics.Path;
import android.graphics.Rect;
import android.media.AudioManager;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;

import java.util.ArrayDeque;
import java.util.List;
import java.util.Locale;
import java.util.regex.Pattern;

/**
 * Watches the YouTube app screen.
 *  - While an ad is showing: mutes the music stream.
 *  - When the Skip button appears: clicks it.
 *  - When the ad is gone: restores the sound (only if we were the ones who muted it).
 */
public class AdSkipService extends AccessibilityService {

    private static final String YT_PACKAGE = "com.google.android.youtube";
    private static final String SKIP_BUTTON_ID = YT_PACKAGE + ":id/skip_ad_button";

    private static final long SCAN_THROTTLE_MS = 150;   // min gap between scans from events
    private static final long POLL_MS = 400;            // re-check while muted
    private static final long UNMUTE_AFTER_MS = 1200;   // ad must be gone this long before unmute
    private static final long CLICK_GAP_MS = 500;       // min gap between skip clicks
    private static final int MAX_NODES = 700;           // safety limit for tree traversal

    // Ad badge such as "Ad · 0:15" or "Ad 1 of 2 · 0:30"
    private static final Pattern AD_BADGE =
            Pattern.compile("^ad(\\s+\\d+\\s+of\\s+\\d+)?\\s*[\\u00B7\\u2022].*");

    private final Handler handler = new Handler(Looper.getMainLooper());
    private AudioManager audio;
    private boolean mutedByUs = false;
    private long lastAdSeen = 0;
    private long lastScan = 0;
    private long lastClick = 0;

    private final Runnable poll = new Runnable() {
        @Override
        public void run() {
            scan();
            if (mutedByUs) {
                handler.postDelayed(this, POLL_MS);
            }
        }
    };

    @Override
    protected void onServiceConnected() {
        super.onServiceConnected();
        audio = (AudioManager) getSystemService(Context.AUDIO_SERVICE);
    }

    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) {
        long now = SystemClock.uptimeMillis();
        if (now - lastScan < SCAN_THROTTLE_MS) {
            return;
        }
        scan();
    }

    @Override
    public void onInterrupt() {
        unmuteIfNeeded();
    }

    @Override
    public void onDestroy() {
        unmuteIfNeeded();
        handler.removeCallbacksAndMessages(null);
        super.onDestroy();
    }

    // ------------------------------------------------------------------

    private void scan() {
        lastScan = SystemClock.uptimeMillis();
        AccessibilityNodeInfo root = getRootInActiveWindow();
        boolean adVisible = false;

        if (root != null) {
            CharSequence pkg = root.getPackageName();
            if (pkg != null && YT_PACKAGE.contentEquals(pkg)) {
                AccessibilityNodeInfo skip = findSkipButton(root);
                if (skip != null) {
                    adVisible = true;
                    clickSkip(skip);
                } else {
                    adVisible = detectAd(root);
                }
            }
        }

        long now = SystemClock.uptimeMillis();
        if (adVisible) {
            lastAdSeen = now;
            muteForAd();
        } else if (mutedByUs && now - lastAdSeen >= UNMUTE_AFTER_MS) {
            unmuteIfNeeded();
        }
    }

    // ---------- skip button -------------------------------------------

    private AccessibilityNodeInfo findSkipButton(AccessibilityNodeInfo root) {
        // 1) by view id (language independent)
        List<AccessibilityNodeInfo> byId = root.findAccessibilityNodeInfosByViewId(SKIP_BUTTON_ID);
        if (byId != null) {
            for (AccessibilityNodeInfo n : byId) {
                if (n.isVisibleToUser()) {
                    return n;
                }
            }
        }
        // 2) by text / content description
        List<AccessibilityNodeInfo> byText = root.findAccessibilityNodeInfosByText("skip");
        if (byText != null) {
            for (AccessibilityNodeInfo n : byText) {
                if (!n.isVisibleToUser()) {
                    continue;
                }
                String t = norm(n.getText());
                String d = norm(n.getContentDescription());
                if (isSkipLabel(t) || isSkipLabel(d)) {
                    return n;
                }
            }
        }
        return null;
    }

    private static boolean isSkipLabel(String s) {
        return s.equals("skip") || s.equals("skip ad") || s.equals("skip ads")
                || s.startsWith("skip ad ");
    }

    private void clickSkip(AccessibilityNodeInfo node) {
        long now = SystemClock.uptimeMillis();
        if (now - lastClick < CLICK_GAP_MS) {
            return;
        }
        lastClick = now;

        AccessibilityNodeInfo cur = node;
        for (int i = 0; i < 5 && cur != null; i++) {
            if (cur.isClickable() && cur.performAction(AccessibilityNodeInfo.ACTION_CLICK)) {
                return;
            }
            cur = cur.getParent();
        }

        // Fallback: tap in the middle of the button
        Rect r = new Rect();
        node.getBoundsInScreen(r);
        if (r.width() > 0 && r.height() > 0) {
            tap(r.centerX(), r.centerY());
        }
    }

    private void tap(int x, int y) {
        Path p = new Path();
        p.moveTo(x, y);
        GestureDescription.StrokeDescription stroke =
                new GestureDescription.StrokeDescription(p, 0, 50);
        GestureDescription gesture = new GestureDescription.Builder().addStroke(stroke).build();
        dispatchGesture(gesture, null, null);
    }

    // ---------- ad detection ------------------------------------------

    private boolean detectAd(AccessibilityNodeInfo root) {
        ArrayDeque<AccessibilityNodeInfo> queue = new ArrayDeque<>();
        queue.add(root);
        int visited = 0;
        while (!queue.isEmpty() && visited < MAX_NODES) {
            AccessibilityNodeInfo n = queue.poll();
            visited++;

            String id = n.getViewIdResourceName();
            if (id != null && (id.contains("ad_progress") || id.contains("skip_ad")
                    || id.contains("ad_badge") || id.contains("ad_countdown"))) {
                return true;
            }
            if (isAdText(norm(n.getText())) || isAdText(norm(n.getContentDescription()))) {
                return true;
            }

            int count = n.getChildCount();
            for (int i = 0; i < count; i++) {
                AccessibilityNodeInfo c = n.getChild(i);
                if (c != null) {
                    queue.add(c);
                }
            }
        }
        return false;
    }

    private static boolean isAdText(String s) {
        if (s.isEmpty()) {
            return false;
        }
        return AD_BADGE.matcher(s).matches()
                || s.contains("visit advertiser")
                || s.contains("why this ad");
    }

    private static String norm(CharSequence cs) {
        return cs == null ? "" : cs.toString().trim().toLowerCase(Locale.ROOT);
    }

    // ---------- audio -------------------------------------------------

    private void muteForAd() {
        if (!mutedByUs && audio != null) {
            try {
                if (audio.isStreamMute(AudioManager.STREAM_MUSIC)) {
                    return; // user already muted - leave it alone
                }
                audio.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_MUTE, 0);
                mutedByUs = true;
            } catch (Exception ignored) {
                return;
            }
        }
        if (mutedByUs) {
            handler.removeCallbacks(poll);
            handler.postDelayed(poll, POLL_MS);
        }
    }

    private void unmuteIfNeeded() {
        if (mutedByUs && audio != null) {
            try {
                audio.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_UNMUTE, 0);
            } catch (Exception ignored) {
                // nothing else we can do
            }
        }
        mutedByUs = false;
        handler.removeCallbacks(poll);
    }
}
